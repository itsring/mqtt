﻿using SettingXmlData.Model;
using SettingXmlData.ViewModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml.Serialization;
using uPLibrary.Networking.M2Mqtt;

namespace SettingXmlData.MQTTClasses
{
    internal class Publish
    {
        public MqttClient client;
        public MainViewModel mainViewModel {  get; set; }
        public Publish(string IP, string PORT)
        {
            this.client = new MqttClient(IP, int.Parse(PORT), false, null, null, MqttSslProtocols.TLSv1_2); 
        }

        public void Connect()
        {
            this.client.Connect(Guid.NewGuid().ToString());
        }

        public void PublishMessage(XMLFIleModel model)
        {
            // TODO :
            // serialize 할 모델을 따로 생성 ? 
            // 가지고 있는 모델로 어떻게 안될까?...
            //XmlSerializer serializer = new XmlSerializer();
            //StringWriter stringWriter = new StringWriter();
            //serializer.Serialize(stringWriter, model);
            //string xmlString = stringWriter.ToString();

            // UTF-8 인코딩을 사용하여 XML 문자열을 byte 배열로 변환
            XElement[] getElemntArray = model.getXmlModel(model.childElement);
            string str = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n<Root>";
            for (int i = 0; i < getElemntArray.Length; i++)
            {
                str += "<" + getElemntArray[i].Name + ">" + getElemntArray[i].Value + "</" + getElemntArray[i].Name + ">\n";
            }
            str += "</Root>";

            byte[] message = Encoding.UTF8.GetBytes(str);

            this.client.Publish(model.topic, message);
        }

        public void setMainViewModel(MainViewModel mainViewModel)
        {
            this.mainViewModel = mainViewModel;
        }
    }
}
