﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace SettingXmlData.Model
{
    internal class FileModelCreater
    {
        public XMLFIleModel CreateModelFromFile(string filePath)
        {
            try
            {
                // 파일에서 첫 줄 읽기 = Topic 
                string firstLine = File.ReadLines(filePath).First();
                // 파일 전체 읽기
                string xmlContent = File.ReadAllText(filePath);
                // 첫줄 다음 라인 부터 xml 이기때문.
                int lastIndexOf_enter = xmlContent.IndexOf("\n");
                // 첫줄 지우고 xml화 하기
                string beforeParse = xmlContent.Substring(lastIndexOf_enter+1, xmlContent.Length - firstLine.Length-2);

                XDocument afterParse = XDocument.Parse(beforeParse);

                // 루트 엘리먼트 가져오기
                XElement rootElement = afterParse.Root;
                XMLFIleModel xmlModel = new();
                xmlModel.topic = firstLine;

                // 각 자식 엘리먼트 순회 및 처리
                foreach (XElement childElement in rootElement.Elements())
                {                 
                    XAttribute attribute = childElement.Attribute("attributeName");
                    if (attribute != null)
                    {
                        string attributeValue = attribute.Value;
                        Console.WriteLine($"Attribute Value: {attributeValue}");
                    }
                    System.Diagnostics.Debug.WriteLine($"file_path : {childElement.Name}, lastIndex = {attribute} , ");
                    xmlModel.childElement.Add(new XElementModel( childElement ));                 
                }

                return xmlModel;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"ex : {ex.Message}");
                throw ex;
            }
        }
    }
}

