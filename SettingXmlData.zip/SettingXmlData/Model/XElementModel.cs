﻿using SettingXmlData.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.RightsManagement;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace SettingXmlData.Model
{
    internal class XElementModel : ViewModelBase
    {
        public XElementModel(XElement el)
        {
            this.name = el.Name.ToString();
            this.content = el.Value.ToString(); ;
        }

        public string name { get; set; }
        public string content { get; set; }

        public string Name
        {
            get { return this.name; }
            set
            {
                this.name = value;
                notifyPropertyChanged(nameof(Name));
            }
        }

        public string Content
        {
            get { return this.content; }
            set
            {
                this.content = value;
                notifyPropertyChanged(nameof(Content));
            }
        }
    }
}
