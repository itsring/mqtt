﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace SettingXmlData.Model
{
    internal class XMLFIleModel
    {
        public ObservableCollection<XElementModel> childElement { get; set; }
        public string topic { get; set; }
        public XMLFIleModel()
        {
            childElement = new();
        }      
        
        public XElement[] getXmlModel(ObservableCollection<XElementModel> childElement)
        {
            XElement[] model = new XElement[childElement.Count];
            foreach (var item in childElement)
            {
                model[childElement.IndexOf(item)] = new XElement(item.Name);
                model[childElement.IndexOf(item)].Value = item.Content;
            }
            return model;
        }
    }
}
