﻿using SettingXmlData.Command;
using SettingXmlData.ViewModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace SettingXmlData.Model
{
    internal class XMLFileNames
    {
        public string FileName { get; set; }
        public string FilePath { get; set; }
        // radio btn event 
        public ICommand RadioClick { get; set; }

        private MainViewModel MainViewModel { get; set; }

        public XMLFileNames(string file = null)
        {
            string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(file);
            //list[i].FileName = file_path;
            FileName = fileNameWithoutExtension;
            FilePath = file;
            RadioClick = new SimpleCommand(RadioButtonDBExam);
            //FileNameAndExtention = fileNameAndExtention;
        }

        public void RadioButtonDBExam()
        {
            // 1. xml 파일 이름 넘겨서 Text Block 에 뿌리기 
            // 2. 
            this.MainViewModel.ClickRadio(FilePath);
          
        }

        public void SettingVM(MainViewModel mainViewModel)
        {
            this.MainViewModel = mainViewModel;
        }
    }
}
