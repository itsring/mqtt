﻿using SettingXmlData.Command;
using SettingXmlData.Model;
using SettingXmlData.MQTTClasses;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows.Media;

namespace SettingXmlData.ViewModel
{
    internal class MainViewModel : ViewModelBase
    {
        Publish publish;
        ObservableCollection<XMLFileNames> XML_List { get; set; }

        // folder path
        private string FolderPath = "..\\..\\xml";
        // xml TagModel
        public XMLFIleModel selectedFileModel { get; set; }
        // message
        public string Not_yet_publish_message { get; set; }
        // IP
        public string ip { get; set; }
        // PORT
        public string port { get; set; }
        // publish btn event
        public ICommand PublishClick { get; set; }

        public MainViewModel()
        {            
            XML_List = new();
            XMLList = new();
            string folderPath = Path.Combine(FolderPath);
            string[] fileNames = Directory.GetFiles(folderPath);
            XMLList = SettingObservable(fileNames);
            Not_yet_publish_message = "";
            IP = "127.0.0.1";
            PORT = "2883";
            PublishClick = new SimpleCommand(MqttPublish);
        }

        public string IP
        {
            get { return ip; }
            set { 
                ip = value;
                notifyPropertyChanged(nameof(IP));
            }
            
        }

        public string PORT
        {
            get { return port; }
            set
            {
                port = value;
                notifyPropertyChanged(nameof(PORT));
            }

        }

        public string Message
        {
            get { return Not_yet_publish_message; }
            set
            {
                Not_yet_publish_message += value;
                notifyPropertyChanged(nameof(Message));
            }

        }

        public XMLFIleModel FileModel
        {
            get { return selectedFileModel; }
            set
            {
                selectedFileModel = value;
                notifyPropertyChanged(nameof(FileModel));
            }

        }

        // xml List
        public ObservableCollection<XMLFileNames> XMLList
        {
            get { return XML_List; }
            set {
                XML_List = value;
                notifyPropertyChanged(nameof(XMLList));
            }
        }

        private ObservableCollection<XMLFileNames> SettingObservable(string[] setting)
        {
            ObservableCollection<XMLFileNames> returnList = new();
            XMLFileNames[] list = new XMLFileNames[setting.Length];
            for (int i = 0; i < setting.Length; i++)
            {
                list[i] = new(setting[i]);
                list[i].SettingVM(this);
                returnList.Add(list[i]);
            }

            return returnList;
        }

        public void ClickRadio(string FilePath)
        {
            FileModelCreater fileModelCreater = new FileModelCreater();
            FileModel = fileModelCreater.CreateModelFromFile(FilePath);
        }

        private void MqttPublish()
        {
            /** 
             * TODO :
             * 1. Mqtt 연결
             * 2. topic 과 XML로 묶어서 전송
             */
            publish = new Publish(IP, PORT);
            publish.Connect();
            publish.setMainViewModel(this);

            publish.PublishMessage(this.FileModel);
        }

    }
}
